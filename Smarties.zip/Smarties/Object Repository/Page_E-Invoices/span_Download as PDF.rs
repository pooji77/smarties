<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_Download as PDF</name>
   <tag></tag>
   <elementGuidId>8944b949-f650-4ab2-beaf-44f7af85efc9</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='View PDF Invoice'])[1]/following::span[3]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.ant-modal-footer > div > button.ant-btn.css-4fk4bg.ant-btn-primary > span</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>[data-testid=&quot;details&quot;]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>c8ed9c42-13de-4752-a4a1-5eb6a552f23f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Download as PDF</value>
      <webElementGuid>0e9c3e7c-a02f-4082-9454-c2ceee30bff5</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/div[5]/div[@class=&quot;ant-modal-root css-4fk4bg&quot;]/div[@class=&quot;ant-modal-wrap&quot;]/div[@class=&quot;ant-modal css-4fk4bg&quot;]/div[2]/div[@class=&quot;ant-modal-content&quot;]/div[@class=&quot;ant-modal-footer&quot;]/div[1]/button[@class=&quot;ant-btn css-4fk4bg ant-btn-primary&quot;]/span[1]</value>
      <webElementGuid>da51353f-87f9-4ede-bc99-c801a0dbc13b</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='View PDF Invoice'])[2]/following::span[3]</value>
      <webElementGuid>f89d6a44-6d3d-4b5f-8cc5-9d50a24d1ee6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='View PDF Invoice'])[1]/following::span[3]</value>
      <webElementGuid>2fbf6005-d500-4c9b-8add-851ba40120f2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Download as PDF']/parent::*</value>
      <webElementGuid>643bf1a8-2c89-4833-8ee6-6ed6918d348f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div/div[2]/div/div[2]/div/button/span</value>
      <webElementGuid>a94d024c-6158-4401-9927-d6b0251fd420</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'Download as PDF' or . = 'Download as PDF')]</value>
      <webElementGuid>7eae5c8d-5f7f-4d26-9015-dd90214aab6a</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
