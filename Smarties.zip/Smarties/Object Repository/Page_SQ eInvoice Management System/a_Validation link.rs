<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Validation link</name>
   <tag></tag>
   <elementGuidId>d23df731-4b3d-4440-8adc-05f2b256a03b</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Original Invoice number'])[1]/following::a[1]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div:nth-of-type(4) > a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;Validation link&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>888289e8-42f6-40b6-9375-bf9f9a3c811c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>target</name>
      <type>Main</type>
      <value>_blank</value>
      <webElementGuid>dece4c40-4cba-4f95-a43a-8d80acf1b2d5</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>https://preprod.myinvois.hasil.gov.my/XSQ48JMAHQ7WJ051BJY719VJ10/share/WM0MMA55T723C8F4BJY719VJ10rlsywB1747281246</value>
      <webElementGuid>4353db77-efb7-4e42-bf66-0c477fb68f28</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Validation link</value>
      <webElementGuid>20e8ffe1-c875-4cf1-a4fd-1c6658055a5f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;root&quot;)/div[@class=&quot;css-uaxenf ant-design-pro ant-pro-layout screen-lg ant-pro-layout-fix-siderbar ant-pro-layout-mix&quot;]/div[@class=&quot;ant-layout ant-layout-has-sider css-4fk4bg&quot;]/div[@class=&quot;ant-pro-layout-container css-uaxenf&quot;]/main[@class=&quot;ant-layout-content ant-pro-layout-content css-uaxenf ant-pro-layout-has-header ant-pro-layout-content-has-page-container css-4fk4bg&quot;]/div[@class=&quot;ant-pro-page-container css-uaxenf&quot;]/div[@class=&quot;ant-pro-grid-content css-uaxenf&quot;]/div[@class=&quot;ant-pro-grid-content-children css-uaxenf&quot;]/div[@class=&quot;css-uaxenf ant-pro-page-container-children-container&quot;]/div[@class=&quot;ant-row css-4fk4bg&quot;]/div[@class=&quot;ant-collapse ant-collapse-icon-position-end ant-collapse-borderless ant-collapse-ghost css-4fk4bg&quot;]/div[@class=&quot;ant-collapse-item ant-collapse-item-active&quot;]/div[@class=&quot;ant-collapse-content ant-collapse-content-active&quot;]/div[@class=&quot;ant-collapse-content-box&quot;]/div[@class=&quot;ant-row css-4fk4bg&quot;]/div[@class=&quot;ant-col ant-col-6 css-4fk4bg&quot;]/div[@class=&quot;ant-descriptions css-4fk4bg&quot;]/div[@class=&quot;ant-descriptions-view&quot;]/table[1]/tbody[1]/tr[@class=&quot;ant-descriptions-row&quot;]/td[@class=&quot;ant-descriptions-item&quot;]/div[@class=&quot;ant-descriptions-item-container&quot;]/span[@class=&quot;ant-descriptions-item-content&quot;]/div[1]/div[4]/a[1]</value>
      <webElementGuid>c996d353-1f3f-46ee-9e84-01cfae047c5a</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='root']/div/div[2]/div[2]/main/div[2]/div[2]/div/div/div[3]/div/div/div[2]/div/div/div[3]/div/div/table/tbody/tr/td/div/span/div/div[4]/a</value>
      <webElementGuid>151b4292-ff03-440f-964f-9c04bc7552a4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Validation link')]</value>
      <webElementGuid>8c1e3aea-f7dd-4b8f-9dcf-9fc244e187b8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Original Invoice number'])[1]/following::a[1]</value>
      <webElementGuid>d54f96fc-eeeb-4f7f-b790-ba63a008560c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Name'])[1]/preceding::a[1]</value>
      <webElementGuid>8139651c-b31b-4c39-83fc-67d3ffc5c396</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Validation link']/parent::*</value>
      <webElementGuid>7c0bd542-c21e-4eb1-abe0-fd0f40b53b93</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, 'https://preprod.myinvois.hasil.gov.my/XSQ48JMAHQ7WJ051BJY719VJ10/share/WM0MMA55T723C8F4BJY719VJ10rlsywB1747281246')]</value>
      <webElementGuid>46ce477d-b22f-48e2-9bf0-30c26022a174</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[4]/a</value>
      <webElementGuid>450f8e28-b363-4b5e-9007-9aa6e54475f4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = 'https://preprod.myinvois.hasil.gov.my/XSQ48JMAHQ7WJ051BJY719VJ10/share/WM0MMA55T723C8F4BJY719VJ10rlsywB1747281246' and (text() = 'Validation link' or . = 'Validation link')]</value>
      <webElementGuid>5a829011-01df-4135-b27a-4eb381d36998</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
