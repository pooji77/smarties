<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_Credit Note</name>
   <tag></tag>
   <elementGuidId>d73db400-922b-4578-84a4-79bbad142e4e</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='rc-tabs-0-tab-3']/span</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>#rc-tabs-0-tab-3 > span</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:text=&quot;Credit Note&quot;s</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>175e6034-cef0-4b3f-a475-1ab105466479</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Credit Note</value>
      <webElementGuid>37983d51-b0b0-425a-a4b2-95522f8244eb</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;rc-tabs-0-tab-3&quot;)/span[1]</value>
      <webElementGuid>e4031f94-bb06-4985-8075-9052eb8cf944</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='rc-tabs-0-tab-3']/span</value>
      <webElementGuid>bc6626f9-3232-40f9-a38b-892b71fba204</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Invoice'])[1]/following::span[1]</value>
      <webElementGuid>91332ce4-fd23-47f0-a7f3-0c3139ce3b20</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='All'])[2]/following::span[1]</value>
      <webElementGuid>e270515b-c274-471e-8c0c-074909fbb657</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Debit Note'])[1]/preceding::span[1]</value>
      <webElementGuid>a783f567-2a00-4f12-9c20-bacfb5af205b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Refund Note'])[1]/preceding::span[2]</value>
      <webElementGuid>cf38ae64-c087-4b45-a399-dadb4e7acf23</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Credit Note']/parent::*</value>
      <webElementGuid>d3562716-d3ab-4ff5-852c-754fb1bd304e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[3]/div/span</value>
      <webElementGuid>24e0a922-5277-4dd8-8886-bba58584168c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'Credit Note' or . = 'Credit Note')]</value>
      <webElementGuid>0aed06e7-f833-4a9d-83f2-8004f66c8c9a</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
