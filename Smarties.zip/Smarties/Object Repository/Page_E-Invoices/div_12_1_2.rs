<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_12_1_2</name>
   <tag></tag>
   <elementGuidId>1494e772-6d81-4363-9aeb-ef7093d6775a</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Sa'])[5]/following::div[16]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>td.ant-picker-cell.ant-picker-cell-range-start.ant-picker-cell-range-end.ant-picker-cell-in-view > div.ant-picker-cell-inner</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>div:nth-child(6) > .ant-picker-dropdown > .ant-picker-range-wrapper > .ant-picker-panel-container > .ant-picker-panel-layout > div > .ant-picker-panels > div > .ant-picker-date-panel > .ant-picker-body > .ant-picker-content > tbody > tr:nth-child(3) > td:nth-child(2) > .ant-picker-cell-inner >> nth=0</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>2134e42a-3b05-4c3b-b36e-1e727689b419</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>ant-picker-cell-inner</value>
      <webElementGuid>1d9dd48e-c3c5-4999-8bbd-2d91e653e7f0</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>12</value>
      <webElementGuid>9b523b16-9beb-4fad-bd90-9e1714a74b7a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/div[4]/div[@class=&quot;ant-picker-dropdown css-4fk4bg ant-picker-dropdown-range ant-picker-dropdown-placement-topLeft&quot;]/div[@class=&quot;ant-picker-range-wrapper ant-picker-date-range-wrapper&quot;]/div[@class=&quot;ant-picker-panel-container ant-picker-date-panel-container&quot;]/div[@class=&quot;ant-picker-panel-layout&quot;]/div[1]/div[@class=&quot;ant-picker-panels&quot;]/div[@class=&quot;ant-picker-panel&quot;]/div[@class=&quot;ant-picker-date-panel&quot;]/div[@class=&quot;ant-picker-body&quot;]/table[@class=&quot;ant-picker-content&quot;]/tbody[1]/tr[3]/td[@class=&quot;ant-picker-cell ant-picker-cell-range-start ant-picker-cell-range-end ant-picker-cell-in-view&quot;]/div[@class=&quot;ant-picker-cell-inner&quot;]</value>
      <webElementGuid>e962f2da-629f-40d1-94ae-7a1942618d5c</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Sa'])[5]/following::div[16]</value>
      <webElementGuid>5de701d9-2181-4687-948b-f1716eb86eb0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Fr'])[5]/following::div[16]</value>
      <webElementGuid>b1c19d7d-f427-4b86-bbce-0a1bebff15f5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Jun'])[3]/preceding::div[27]</value>
      <webElementGuid>f413a0fc-22ad-441a-89a0-4e049d190ed2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Su'])[6]/preceding::div[29]</value>
      <webElementGuid>57e0bb4f-4db8-48a3-a5c7-3890f2574f5e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[4]/div/div/div[2]/div/div/div/div/div/div[2]/table/tbody/tr[3]/td[2]/div</value>
      <webElementGuid>7b303c76-95a7-4751-b2ab-689bd22115e6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = '12' or . = '12')]</value>
      <webElementGuid>f5cc0ed5-2e2f-4370-abf9-f76f8726bc87</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
