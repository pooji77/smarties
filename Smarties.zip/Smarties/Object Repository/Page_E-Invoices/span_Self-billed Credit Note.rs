<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_Self-billed Credit Note</name>
   <tag></tag>
   <elementGuidId>860a0cb7-e5f2-4f92-8619-09ce4655f00a</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='rc-tabs-0-tab-7']/span</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>#rc-tabs-0-tab-7 > span</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:text=&quot;Self-billed Credit Note&quot;i</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>1a838beb-291b-412b-af59-43c49ea81850</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Self-billed Credit Note</value>
      <webElementGuid>ebada18a-cabe-4ec0-808b-2f59d8f2c0ef</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;rc-tabs-0-tab-7&quot;)/span[1]</value>
      <webElementGuid>dbc5a8d0-ad49-4460-ba7b-05eef15bbfb3</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='rc-tabs-0-tab-7']/span</value>
      <webElementGuid>f524a8d4-0979-4fdf-8a81-f28d6f544969</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Self-billed Invoice'])[1]/following::span[1]</value>
      <webElementGuid>cbf157b0-132c-4ec5-ae8c-c9c8220d6967</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Refund Note'])[1]/following::span[2]</value>
      <webElementGuid>0ce22f54-e8d9-4b6e-a07b-164f99ab2a29</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Self-billed Debit Note'])[1]/preceding::span[1]</value>
      <webElementGuid>4abe9175-3a43-4641-a0a4-b299c1ea8bc0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Self-billed Refund Note'])[1]/preceding::span[2]</value>
      <webElementGuid>47909587-a9b4-4cb5-be1d-6a74f02773cb</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Self-billed Credit Note']/parent::*</value>
      <webElementGuid>b9ef5d0d-35eb-4eb8-bcb2-72118e603136</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[7]/div/span</value>
      <webElementGuid>10aa0f1b-8984-4a67-ace9-dc064f4a2e88</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'Self-billed Credit Note' or . = 'Self-billed Credit Note')]</value>
      <webElementGuid>00ffeeea-2237-4c9e-a5c9-01af7b7ef90e</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
