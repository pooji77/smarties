<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_Debit Note</name>
   <tag></tag>
   <elementGuidId>41cf9084-73f2-4777-8d91-f5ddd4089591</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='rc-tabs-0-tab-4']/span</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>#rc-tabs-0-tab-4 > span</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:text=&quot;Debit Note&quot;s</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>82f1177a-204d-4639-b42e-e58802c74749</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Debit Note</value>
      <webElementGuid>b5392d4d-e185-45ed-855d-460570377260</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;rc-tabs-0-tab-4&quot;)/span[1]</value>
      <webElementGuid>9d71644c-450e-497e-a433-85ba3658bf53</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='rc-tabs-0-tab-4']/span</value>
      <webElementGuid>991f07ab-f2e4-4ebd-bed5-d5a7f3794ae0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Credit Note'])[1]/following::span[1]</value>
      <webElementGuid>5cdc6785-9ac4-4734-98ad-029c8bf25193</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Invoice'])[1]/following::span[2]</value>
      <webElementGuid>92bd1fcc-e36f-405c-8d66-fa95a686cd8c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Refund Note'])[1]/preceding::span[1]</value>
      <webElementGuid>2ce2a964-ade2-4a70-97e4-b19202b6f907</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Self-billed Invoice'])[1]/preceding::span[2]</value>
      <webElementGuid>19906de8-1da8-4cb8-b354-dbae7e41856f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Debit Note']/parent::*</value>
      <webElementGuid>be6205ab-2217-4acd-b19b-6fd956c064d8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[4]/div/span</value>
      <webElementGuid>79e32558-c4fe-421f-9594-d96ee77078aa</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'Debit Note' or . = 'Debit Note')]</value>
      <webElementGuid>18c2070b-2604-4f64-94ac-b12acc7b6047</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
