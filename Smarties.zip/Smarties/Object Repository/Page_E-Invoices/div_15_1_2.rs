<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_15_1_2</name>
   <tag></tag>
   <elementGuidId>c20e20ba-a7ca-422b-ab92-9152d7708ea4</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Sa'])[5]/following::div[19]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div:nth-of-type(4) > div.ant-picker-dropdown.css-4fk4bg.ant-picker-dropdown-range.ant-picker-dropdown-placement-topLeft > div.ant-picker-range-wrapper.ant-picker-date-range-wrapper > div.ant-picker-panel-container.ant-picker-date-panel-container > div.ant-picker-panel-layout > div > div.ant-picker-panels > div.ant-picker-panel > div.ant-picker-date-panel > div.ant-picker-body > table.ant-picker-content > tbody > tr:nth-of-type(3) > td.ant-picker-cell.ant-picker-cell-range-end.ant-picker-cell-in-view > div.ant-picker-cell-inner</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>div:nth-child(6) > .ant-picker-dropdown > .ant-picker-range-wrapper > .ant-picker-panel-container > .ant-picker-panel-layout > div > .ant-picker-panels > div > .ant-picker-date-panel > .ant-picker-body > .ant-picker-content > tbody > tr:nth-child(3) > td:nth-child(5) > .ant-picker-cell-inner >> nth=0</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>0be854fc-66f9-4acd-b5fd-d25825020b9f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>ant-picker-cell-inner</value>
      <webElementGuid>9a19d46a-fe14-4755-baed-b3290b43136e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>15</value>
      <webElementGuid>9b67a83f-155f-45a3-b55a-c9ff00e70e3f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/div[4]/div[@class=&quot;ant-picker-dropdown css-4fk4bg ant-picker-dropdown-range ant-picker-dropdown-placement-topLeft&quot;]/div[@class=&quot;ant-picker-range-wrapper ant-picker-date-range-wrapper&quot;]/div[@class=&quot;ant-picker-panel-container ant-picker-date-panel-container&quot;]/div[@class=&quot;ant-picker-panel-layout&quot;]/div[1]/div[@class=&quot;ant-picker-panels&quot;]/div[@class=&quot;ant-picker-panel&quot;]/div[@class=&quot;ant-picker-date-panel&quot;]/div[@class=&quot;ant-picker-body&quot;]/table[@class=&quot;ant-picker-content&quot;]/tbody[1]/tr[3]/td[@class=&quot;ant-picker-cell ant-picker-cell-range-end ant-picker-cell-in-view&quot;]/div[@class=&quot;ant-picker-cell-inner&quot;]</value>
      <webElementGuid>ceca3d02-5284-4c6b-8b6a-f3b4fdf540db</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Sa'])[5]/following::div[19]</value>
      <webElementGuid>367c0464-4e05-4725-803d-0320c59eecbf</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Fr'])[5]/following::div[19]</value>
      <webElementGuid>183286ea-884e-4cf7-a5b2-d748cec46bfa</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Jun'])[3]/preceding::div[24]</value>
      <webElementGuid>ea1de8bc-b8cf-4280-9bf0-4e20f02bda46</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Su'])[6]/preceding::div[26]</value>
      <webElementGuid>d56bac6f-26eb-4777-a2fd-741b29bfdf68</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[4]/div/div/div[2]/div/div/div/div/div/div[2]/table/tbody/tr[3]/td[5]/div</value>
      <webElementGuid>a54c156d-24b3-403d-b96d-59383ed8cdc2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = '15' or . = '15')]</value>
      <webElementGuid>77ecc3da-d11a-4c8c-991f-ea3d104dbe59</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
