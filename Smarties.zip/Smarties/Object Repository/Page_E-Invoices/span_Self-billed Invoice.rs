<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_Self-billed Invoice</name>
   <tag></tag>
   <elementGuidId>280018b7-cf86-41b5-9678-171431293ab3</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='rc-tabs-0-tab-6']/span</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>#rc-tabs-0-tab-6 > span</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=tab[name=&quot;Self-billed Invoice&quot;i] >> span</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>fd587a48-599d-45fa-828b-37acdcdde131</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Self-billed Invoice</value>
      <webElementGuid>8a20e8e7-6302-4886-8f63-2eea544cc892</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;rc-tabs-0-tab-6&quot;)/span[1]</value>
      <webElementGuid>48fb927a-2e77-4801-b9eb-404c37269307</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='rc-tabs-0-tab-6']/span</value>
      <webElementGuid>f456fd91-3240-4971-9cdb-15cac8ffbe68</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Refund Note'])[1]/following::span[1]</value>
      <webElementGuid>7aaf778f-6593-45f1-a4e3-cfd3ed8825f3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Debit Note'])[1]/following::span[2]</value>
      <webElementGuid>dbf4ea1a-b8ee-43f8-8cd3-b6e87378b234</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Self-billed Credit Note'])[1]/preceding::span[1]</value>
      <webElementGuid>b8d2fccd-b8f1-443a-a038-4716f961faac</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Self-billed Debit Note'])[1]/preceding::span[2]</value>
      <webElementGuid>8ae57b6a-4e26-40c4-8614-bd2c00f77ddc</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Self-billed Invoice']/parent::*</value>
      <webElementGuid>cfc56351-53ba-4952-b990-fe47ebf9b602</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[6]/div/span</value>
      <webElementGuid>e9206036-8746-4837-beff-a38020a3ce99</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'Self-billed Invoice' or . = 'Self-billed Invoice')]</value>
      <webElementGuid>8d98273f-beb6-4215-a1e5-1aaf70b0f818</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
