<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_Refund Note</name>
   <tag></tag>
   <elementGuidId>54e91735-d796-4411-884a-abe172f9564b</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='rc-tabs-0-tab-5']/span</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>#rc-tabs-0-tab-5 > span</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:text=&quot;Refund Note&quot;s</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>eae35ccc-9737-4b49-8564-a3b7fb7566b9</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Refund Note</value>
      <webElementGuid>db9b75ee-ba3d-4d9e-b6a6-0f20ea3a1916</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;rc-tabs-0-tab-5&quot;)/span[1]</value>
      <webElementGuid>f5090474-3457-4438-a7c5-1cfa112757e0</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='rc-tabs-0-tab-5']/span</value>
      <webElementGuid>e8ec7dc9-654d-423e-8971-49db131f4839</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Debit Note'])[1]/following::span[1]</value>
      <webElementGuid>2667e476-2882-4751-bb10-e70c83dfa21f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Credit Note'])[1]/following::span[2]</value>
      <webElementGuid>52421ad6-0264-4274-937f-1887ef8f7e0b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Self-billed Invoice'])[1]/preceding::span[1]</value>
      <webElementGuid>32fcf73d-4913-4f9e-8e7f-54524b895347</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Self-billed Credit Note'])[1]/preceding::span[2]</value>
      <webElementGuid>9941b20d-4322-4e49-abf6-40a9e630cce1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Refund Note']/parent::*</value>
      <webElementGuid>5c7b0969-cfcd-4581-bfef-6fc0cae53767</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[5]/div/span</value>
      <webElementGuid>a0e518d4-eec6-4177-a673-284f2837c8a3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'Refund Note' or . = 'Refund Note')]</value>
      <webElementGuid>b8a2e590-6635-4c57-b50b-539746a83ebf</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
